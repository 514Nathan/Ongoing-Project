public class LinkedArrayQueue<E> {
  //don't forget the member data
	private int size =0 ;
	private int NAR= 0;//Number of Array
	private int front =0;
	private int back = -1;
	SinglyLinkedList<E[]> test = new SinglyLinkedList<>(); 
	

	
  //the default constructor
  public LinkedArrayQueue() {  }

  //return the number of elements in the queue
  public int size() {
	return size;  }

  //return the number of arrays currently storing elements
  public int numArrays() {
	return NAR; }

  //test if the queue is empty
  public boolean isEmpty() {
	return  size ==0 ; }
  
  //return the element at the front of the queue. return null if queue is empty
  public E first() {
	return	test.first()[front];  }

  //return the element at the back of the queue. return null if queue is empty
  public E last() {
	
	return 	test.last()[back];  }

  //push e to the back of the queue.
  public void enqueue(E e) {  
	  if(isEmpty()) {
		test.addlast((E[])new Object[8]);
		NAR++;
	  }//if the linked array is empty create a new array in the singlylinkedlist
	  if(back == 7) {
		  test.addlast((E[]) new Object[8]);
		  NAR++;
		  back = -1;
	  }//if the array is full add a new array in the linkedlist, increment NAR by 1, and set back to -1. (7 is the index)
	  ++back; //back get increment by one before hand (if back was at 7 it will start over at 0)
	  test.last()[back] = e;  //set the new element at the last array in the singlylinkedlist at index "back"
	  size++;//number of elements increased, so, the size gets incremented by one
	  
  }

  //pop and return the element at the front of the queue. return null if queue is empty
  public E dequeue(){
	  E something = test.first()[front];//Remember the element at the front, for the return.
	  if(isEmpty()) {
	return null;  }
	 
	  else if(front == 7) { 
		 test.removeFirst();
		 front = -1;
		 NAR--;
	  }//if the front element is the last element in the array, remove that array/node (it will be set to the next node
	  	//in the singlylinkedlist class). front is set to -1 (will be incremented to 0 later) and NAR decrement by 1.
	  front++; //front get incremented, if front was 7 it will start over at 0 else it will increase by 1
	  size--;//the amount of element decreased by one, so, size will get decrement by one.
	  return something;
}
}