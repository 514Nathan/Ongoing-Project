//Note that <E extends Comparable>. Therefore you should use Comparable
//instead of Object while creating arrays and casting them to generic type.
//Also use compareTO() instead of < or > while comparing generic elements
public class MaxMinStack<E extends Comparable<E>> {
	private int size = 0; 
	private int Capacity; 
	private E[] max ;
	private E[] min ;
	private E[] stack;
	private int placeholdermax =0; 
	private int placeholdermin =0;
  //the default constructor

public MaxMinStack() { 
	this(10);
  } //call "itself" with an input to the parameter of 10.


//another constructor which returns a stack of specified size
  @SuppressWarnings("unchecked")
  public MaxMinStack(int ary_size) {
	  Capacity = ary_size;
	 stack = (E[]) new Comparable[ary_size]; 
	 max = (E[]) new Comparable[ary_size]; 
	 min = (E[]) new Comparable[ary_size]; 
  }//create 3 Array stacks with the a size of the parameter and an int variable to 
  	//remember the size for capacity method

  //return the element on top of the stack without removing it. return null if stack is empty.
  public E top() { 
	
	  if(isEmpty()) {
		  return null;
	  }else {
	
		  return stack[size -1 ];
	  }
	  
  } //return the top element which is the current size of the array -1(this is for the index). 

  //return the number of elements in the stack
  public int size() { 
	  return size;
  }//return the amount of elements in the "stack" stack

  //test if the stack is empty
  public boolean isEmpty() {return size == 0; }

  //return the actual capacity of the stack(not the number of elements stored in it).
  public int capacity() {  
	  return Capacity;
  }

  //return the maximum value stored in the stack. return null if stack is empty.
  public E maximum() { 
	  
	  return max[placeholdermax];
  }

  //return the minimumvalue stored in the stack. return null if stack is empty.
  public E minimum() { 
	  
	  return min[placeholdermin];
  }

  //push a new element onto the stack
  public void push(E e) throws IllegalStateException { 
	  if(size == stack.length) {throw new IllegalStateException("Stack is full"); }else {
		  stack[size++]=e; //if the stack is full return exception else add it to "stack" and size increase after
		  if (max[placeholdermax] == null ||min[placeholdermin] == null ) {
			  max[placeholdermax] =e ;
			  min[placeholdermin] =e ;
		  }//if max or min is null push the new element to the max and min stack
		  else { 
			  if( e.compareTo(max[placeholdermax]) >= 0 ) { 
			  max[placeholdermax + 1] = e; placeholdermax++;  }
			  if (e.compareTo(min[placeholdermin]) <= 0 ) { 
			  min[placeholdermin + 1] = e; placeholdermin++; }
		  }//if the element is equal to or (less than for min) or (greater than for max) add it to the 
		  	//respected stack. Equal to is to store more than one of the same element, so 
		  	//the amount of element of the same type shouldn't be affected by pop.
	  }
	  
	  
  }

  //pop the element on top of the stack and return it. return null if stack is empty.
  public E pop() { 
	  if(isEmpty()) {return null; }
	  else {
	  E removing = stack[size - 1];
	  stack[size -1 ] = null;
	  size--; //remove the top element unless it's empty
	  if(removing.compareTo(max[placeholdermax]) == 0) { 
		  max[placeholdermax ] =null; placeholdermax--;}
	  if(removing.compareTo(min[placeholdermin]) == 0) {
		  max[placeholdermin ] =null; placeholdermin--;  }
	  return removing;
	  }}
  //if the element is the same as max or min pop that element as well and the placeholder
  //or the current top decrement by 1.
}