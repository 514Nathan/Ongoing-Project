﻿using System;
using System.Collections.Generic;
using System.Data.SqlTypes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace DataLibrary.Models
{
    public class OppurtunityModel
    {
        public int Opp_ID { get; set; }
        public string Opp_Name { get; set; }
        public string Opp_Date { get; set; }
        public string Opp_Center { get; set; }
        public string Opp_Desc { get; set; }
    }
}
