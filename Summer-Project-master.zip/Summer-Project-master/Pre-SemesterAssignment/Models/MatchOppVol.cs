﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Pre_SemesterAssignment.Models
{
    public class MatchOppVol { 
   
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string UserName { get; set; }

        public string Name { get; set; }

        public string Center { get; set; }

        public string Description { get; set; }


    }
}
