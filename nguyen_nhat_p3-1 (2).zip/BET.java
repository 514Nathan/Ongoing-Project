
import java.util.Stack;
import java.util.stream.IntStream;

public class BET<E> {
	private BinaryNode<E> n = null;

	public BET() {
	}

	public BET(String expr, char mode) throws IllegalStateException {
		if (mode == 'i') {
			if (this.buildFromInfix(expr) == false) {
				throw new IllegalStateException("Invalid notation: " + expr);
			}
		} else if (mode == 'p') {
			if (this.buildFromPostfix(expr) == false) {
				throw new IllegalStateException("Invalid notation: " + expr);
			}
		} else {
			throw new IllegalStateException("Invalid notation:");
		}
	}

	@SuppressWarnings("unchecked")
	public boolean buildFromPostfix(String postfix) {

		n = null;
		BinaryNode<E> tree = new BinaryNode<E>();
		Stack<E> stack = new Stack<E>();
		int stringlength = postfix.length();
		String some = "";
		if (stringlength == 0) {
			return false; // if the string is empty
		}
		String some1 = "";
		String some2 = "";
		for (int i = 0; i < postfix.length(); i++) {
			while (postfix.charAt(i) != ' ') {
				if (i == postfix.length() - 1) {
					return false;
				}
				some1 += postfix.charAt(i);
				i++;
			}
     
			i++;
			while (postfix.charAt(i) != ' ') {
				if (i == postfix.length() - 1) {
					some += postfix.charAt(i);
					break;
				}
				some2 += postfix.charAt(i);
				i++;
			}
			break;
		}

		if (some1.equals("(") || some2.equals("+") || some2.equals("-") || some2.equals("*") || some2.equals("/")) {

			if (some2.equals(")")) {
				return false;
			} else {

				if (this.buildFromInfix(postfix)) {
				} else {
					return false;
				}
			}

		} else {

			for (int i = 0; i < stringlength; i++) {
				while (postfix.charAt(i) != ' ') {
					if (i == postfix.length() - 1) {
						some += postfix.charAt(i);
						break;
					}
					some += postfix.charAt(i);
					i++;
				}

				if (some.equals("+") || some.equals("-") || some.equals("/") || some.equals("*")) {
					if (stack.isEmpty()) {
						return false;
					}
					BinaryNode<E> temp = tree.addRoot((E) some);

					tree.root.setRight((BinaryNode<E>) stack.pop());

					if (stack.isEmpty()) {
						return false;
					}

					tree.root.setLeft((BinaryNode<E>) stack.pop());
					stack.push((E) tree.root);
				} else {

					BinaryNode<E> temp3 = tree.createNode((E) some, null, null, null);
					stack.push((E) temp3);

				}
				some = "";

			}
      if (stack.isEmpty() || stack.size() != 1 ) {
  
					return false;
				}
			n = tree.root;
		}

		return true;
	}

	@SuppressWarnings({ "unchecked", "unused" })
	public boolean buildFromInfix(String infix) {

		n = null;
		String some = "";
		Stack<E> stack = new Stack<E>();
		Stack<E> stack2 = new Stack<E>();
		BinaryNode<E> tree = new BinaryNode<E>();

		String some1 = "";
		String some2 = "";
		for (int i = 0; i < infix.length(); i++) {
			while (infix.charAt(i) != ' ') {
				if (i == infix.length() - 1) {
				return false;
				}
				some1 += infix.charAt(i);
				i++;
			}
      if(i == infix.length()){
        return false;
      }
			i++;
			while (infix.charAt(i) != ' ') {
				if (i == infix.length() - 1) {
					some += infix.charAt(i);
					break;
				}
				some2 += infix.charAt(i);
				i++;
			}
			break;
		}

		if (!some1.equals("(") && !some2.equals("+") && !some2.equals("-") && !some2.equals("*")
				&& !some2.equals("/")) {

			if (some2.equals(")")) {
				return false;
			} else {
				if (this.buildFromPostfix(infix)) {
				} else {
					return false;
				}
			}

		} else {

			for (int i = 0; i < infix.length(); i++) {

				while (infix.charAt(i) != ' ') {
					if (i == infix.length() - 1) {
						some += infix.charAt(i);
						break;
					}
					some += infix.charAt(i);
					i++;
				}
			
				if (some.equals("(")) {

					stack2.push((E) some);

				} else if (some.equals("+") || some.equals("-")) {
					if (stack.isEmpty()) {

						return false;
					}
					if (!stack2.isEmpty()) {
						if (stack2.peek().equals("+") || stack2.peek().equals("-")) {

							BinaryNode<E> temp = tree.addRoot(stack2.pop());

							tree.root.setRight((BinaryNode<E>) stack.pop());

							BinaryNode<E> t = (BinaryNode<E>) stack.pop();
							tree.root.setLeft((BinaryNode<E>) t);
							stack.push((E) tree.root);

						}
					}

					stack2.push((E) some);

				} else if (some.equals(")")) {

					if (stack2.peek().equals("(")) {
						stack2.pop();
					} else {
						while (!stack2.peek().equals("(")) {

							BinaryNode<E> temp = tree.addRoot(stack2.pop());

							tree.root.setRight((BinaryNode<E>) stack.pop());
							tree.root.setLeft((BinaryNode<E>) stack.pop());

							if (stack2.isEmpty()) {
								return false;
							}
							stack.push((E) tree.root);
						}
						

						stack2.pop();

					}

				} else if (some.equals("*") || some.equals("/")) {

					stack2.push((E) some);
					some = "";
					i++;
					while (infix.charAt(i) != ' ') {
						if (i == infix.length() - 1) {
							some += infix.charAt(i);
							break;
						}
						some += infix.charAt(i);
						i++;
					}
					if (some.equals("+") || some.equals("*") || some.equals("/") || some.equals("-") || some.equals(")")) {
						return false;
					}else if(some.equals("(")) {
						stack2.push((E) some);
						
					}else {
					BinaryNode<E> temp3 = tree.createNode((E) some, null, null, null);
					stack.push((E) temp3);

					BinaryNode<E> temp = tree.addRoot(stack2.pop());

					tree.root.setRight((BinaryNode<E>) stack.pop());

					BinaryNode<E> t = (BinaryNode<E>) stack.pop();
					tree.root.setLeft((BinaryNode<E>) t);

					stack.push((E) tree.root);
					}
				} else {
					BinaryNode<E> temp3 = tree.createNode((E) some, null, null, null);
					stack.push((E) temp3);
				}

				some = "";

			}

			while (!stack2.isEmpty()) {

				if (stack.isEmpty()) {
					return false;
				}
				BinaryNode<E> temp = tree.addRoot(stack2.pop());
				tree.root.setRight((BinaryNode<E>) stack.pop());

				if (stack.isEmpty()) {
					return false;
				}

				tree.root.setLeft((BinaryNode<E>) stack.pop());
				stack.push((E) temp);

			}
      if (stack.isEmpty() || stack.size() != 1 ) {
					return false;
				}

			n = tree.root;

		}

		return true;
	}

	public void printInfixExpression() {
		this.printInfixExpression(n);
	}

	public void printPostfixExpression() {

		this.printPostfixExpression(n);
	}

	public int size() {

		return this.size(n);
	}

	public boolean isEmpty() {
		return this.size() == 0;
	}

	public int leafNodes() {
		return this.leafNodes(n);
	}

	// recursive
	@SuppressWarnings("rawtypes")
	private void printInfixExpression(BinaryNode n) {
		if (n != null) {
			if (n.getLeft() != null && n.getRight() != null) {
				System.out.print("( ");
			}
			this.printInfixExpression(n.getLeft());

			System.out.print(n.getElement() + " ");

			this.printInfixExpression(n.getRight());

			if (n.getLeft() != null && n.getRight() != null) {
				System.out.print(") ");
			}
		}

	}

	@SuppressWarnings({ "rawtypes", "unchecked", "unused" })
	private void makeEmpty(BinaryNode t) {

		if (t != null) {

			this.makeEmpty(t.getLeft());
			this.makeEmpty(t.getRight());
			t.setElement(null);
			t.setLeft(null);
			t.setRight(null);
			t.setParent(null);
		} else if (t == null) {
			t = null;

		}
	}

	private void printPostfixExpression(@SuppressWarnings("rawtypes") BinaryNode n) {
		if (n != null) {

			this.printPostfixExpression(n.getLeft());
			this.printPostfixExpression(n.getRight());
			System.out.print(n.getElement() + " ");

		}
	}

	@SuppressWarnings("rawtypes")
	private int size(BinaryNode t) {
		if (t == null) {

			return 0;

		} else {

			if (t.getRight() != null && t.getLeft() != null) {

				return 1 + (size(t.getRight()) + size(t.getLeft()));

			}

			else {

				return (1 + size(t.getRight()) + size(t.getLeft()));
			}
		}

	}

	@SuppressWarnings("rawtypes")
	private int leafNodes(BinaryNode t) {
		if (t == null) {

			return 0;
		} else if (t.getRight() == null && t.getLeft() == null) {

			return 1;
		} else {
			return (leafNodes(t.getRight()) + leafNodes(t.getLeft()));
		}

	}

	private static class BinaryNode<E> {
		private E element; // an element stored at this node
		private BinaryNode<E> parent; // a reference to the parent node (if any)
		private BinaryNode<E> left; // a reference to the left child (if any)
		private BinaryNode<E> right; // a reference to the right child (if any)
		private BinaryNode<E> root = null;

		public BinaryNode(E e, BinaryNode<E> above, BinaryNode<E> leftChild, BinaryNode<E> rightChild) {
			element = e;
			parent = above;
			left = leftChild;
			right = rightChild;
		}

		public BinaryNode() {
		}

		public E getElement() {
			return element;
		}

		@SuppressWarnings("unused")
		public BinaryNode<E> getParent() {
			return parent;
		}

		public BinaryNode<E> getLeft() {
			return left;
		}

		public BinaryNode<E> getRight() {
			return right;
		}

		public void setElement(E e) {
			element = e;
		}

		public void setParent(BinaryNode<E> parentNode) {
			parent = parentNode;
		}

		public void setLeft(BinaryNode<E> leftChild) {
			left = leftChild;
		}

		public void setRight(BinaryNode<E> rightchild) {
			right = rightchild;
		}

		public BinaryNode<E> addRoot(E e) throws IllegalStateException {
			root = createNode(e, null, null, null);
			return root;
		}

		private BinaryNode<E> createNode(E e, BinaryNode<E> parent, BinaryNode<E> left, BinaryNode<E> right) {
			return new BinaryNode<E>(e, parent, left, right);
		}

		public BinaryNode<E> addLeft(BinaryNode<E> parent, E e) throws IllegalArgumentException {
			if (parent.getLeft() != null) {
				throw new IllegalArgumentException("p already has a left child");
			}

			BinaryNode<E> child = createNode(e, parent, null, null);
			parent.setLeft(child);
			return child;
		}

		public BinaryNode<E> addRight(BinaryNode<E> parent, E e) throws IllegalArgumentException {
			if (parent.getRight() != null) {
				throw new IllegalArgumentException("p already has a right child");
			}
			BinaryNode<E> child = createNode(e, parent, null, null);
			parent.setRight(child);
			return child;
		}
	}

}
